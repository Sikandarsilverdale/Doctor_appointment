# -*- coding: utf-8 -*-
# from odoo import http


# class ProjectLucidChart(http.Controller):
#     @http.route('/project_lucid_chart/project_lucid_chart', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/project_lucid_chart/project_lucid_chart/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('project_lucid_chart.listing', {
#             'root': '/project_lucid_chart/project_lucid_chart',
#             'objects': http.request.env['project_lucid_chart.project_lucid_chart'].search([]),
#         })

#     @http.route('/project_lucid_chart/project_lucid_chart/objects/<model("project_lucid_chart.project_lucid_chart"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('project_lucid_chart.object', {
#             'object': obj
#         })
